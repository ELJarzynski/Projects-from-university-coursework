<?php
class Cfg
{

     // Stałe pole przechowujące nazwę użytkownika.
    public static string $user_name = "kamil";

     // Stałe pole przechowujące hasło użytkownika.
      public static string $user_pass = "limos1";
}
?>